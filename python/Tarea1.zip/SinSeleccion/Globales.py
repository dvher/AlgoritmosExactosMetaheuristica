import time

global soluciones
global time_start

soluciones = []
time_start = time.time()
