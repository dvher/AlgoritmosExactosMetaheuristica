import time

global soluciones
global time_start
global row_order

soluciones = []
row_order = []
time_start = time.time()
